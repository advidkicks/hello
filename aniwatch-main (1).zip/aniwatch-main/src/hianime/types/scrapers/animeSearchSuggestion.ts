import type { AnimeSearchSuggestion } from "../anime.js";

export type ScrapedAnimeSearchSuggestion = {
    suggestions: AnimeSearchSuggestion[];
};
