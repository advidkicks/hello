# [2.24.0](https://github.com/ghoshRitesh12/aniwatch/compare/v2.23.5...v2.24.0) (2025-07-27)



## [2.23.5](https://github.com/ghoshRitesh12/aniwatch/compare/v2.23.4...v2.23.5) (2025-07-27)



## [2.23.4](https://github.com/ghoshRitesh12/aniwatch/compare/v2.23.3...v2.23.4) (2025-07-27)


### Bug Fixes

* temporary fix for the megacloud decryptor ([2314d3f](https://github.com/ghoshRitesh12/aniwatch/commit/2314d3f8c0a094067f39e9031f02687d166e6bd9))



## [2.23.3](https://github.com/ghoshRitesh12/aniwatch/compare/v2.23.2...v2.23.3) (2025-06-17)


### Bug Fixes

* megacloud sources ([e9ceb65](https://github.com/ghoshRitesh12/aniwatch/commit/e9ceb65a359ce272ae974c25e7071ffa2d25a0fe))



## [2.23.2](https://github.com/ghoshRitesh12/aniwatch/compare/v2.23.1...v2.23.2) (2025-06-09)


### Reverts

* domain name to hianimez.to ([bfc402a](https://github.com/ghoshRitesh12/aniwatch/commit/bfc402a4ccfb19950e8c8cb06413c14b80c0504e))



